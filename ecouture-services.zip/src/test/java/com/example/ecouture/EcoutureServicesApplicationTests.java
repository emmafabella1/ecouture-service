package com.example.ecouture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoutureServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
